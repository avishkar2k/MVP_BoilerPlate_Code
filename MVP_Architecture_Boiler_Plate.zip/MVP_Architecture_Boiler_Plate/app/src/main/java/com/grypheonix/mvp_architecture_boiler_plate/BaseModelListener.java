package com.grypheonix.mvp_architecture_boiler_plate;

/**
 * Created at Appinventiv on 23/1/18 at IST 7:10 PM
 * Project MVP_Architecture_Boiler_Plate
 * @author avishkar
 * @version 1.0
 * @since 1.0
 *
 */

public interface BaseModelListener {
    void noNetworkError();
}